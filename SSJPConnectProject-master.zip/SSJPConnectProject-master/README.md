


SSJP Connect App is an android based application. In this application student can see all the Notices, Time-Table, Results, and other study materials provided by our app. 
The main aim of building this application is that to connect student to study's digitally using mobile phone. In this application admin can upload the notices, time table, results and other study material by using admin login and the students can access this all using user login.

#App Functionalities
 In this application user can create there account and login to there account.
 Once the user login to there account they can access all the data available on the application.
 The user can view there MSBTE exam result using our application.
 Also User can get all study material such as manuals with answer, model answer paper, etc. 


![Screenshot_20210521-235930_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195381342-6fa3c11b-f07a-4960-bb76-e5817424470b.jpg)


![Screenshot_20210522-000017_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195379795-edc8a44d-4b4b-4cd0-9c37-f2169ccf7761.jpg)
![Screenshot_20210522-000026_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195379822-e7920f0b-03f6-4212-a69d-e6c55c11f688.jpg)
![Screenshot_20210522-000034_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195379853-74f06ff5-3e6d-42c9-8663-787142ecbcb4.jpg)


![Screenshot_20210522-000054_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380709-e2290193-ba64-4d08-ba90-ae1ae65da375.jpg)
![Screenshot_20210522-000116_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380748-9ce7ed2c-a97a-46f7-a0bd-af2b6893ff6a.jpg)
![Screenshot_20210522-000125_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380766-fa96d5d5-9cf3-4be3-acc1-d343b0eeb9a4.jpg)
![Screenshot_20210522-000136_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380799-74b1b6fc-5fa3-4791-adcc-2e3b61e9b9c5.jpg)
![Screenshot_20210522-000933_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380838-e73c8408-1bcf-4e18-8b96-d1fe666099ff.jpg)
![Screenshot_20210522-000938_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380867-641b78e8-1282-4efe-a9f8-7d576175233b.jpg)
![Screenshot_20210522-000943_SSJP CONNECT](https://user-images.githubusercontent.com/77188914/195380889-5a418845-b35f-45e4-b3b7-27f81f2d52a6.jpg)


https://user-images.githubusercontent.com/77188914/195382311-e6f4534d-14e3-4c79-bdc4-da5a6946ec90.mp4

